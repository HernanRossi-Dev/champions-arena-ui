import React from 'react';

export default class ItemsComponent extends React.Component {


	render() {
		return (
			<div>Under construction.</div>
		);
	};

}