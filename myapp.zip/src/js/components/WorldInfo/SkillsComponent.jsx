import React from 'react';

export default class SkillsComponent extends React.Component {


	render() {
		return (
			<div>Under construction.</div>
		);
	};

}