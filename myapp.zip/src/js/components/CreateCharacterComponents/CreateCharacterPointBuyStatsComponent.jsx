import React from "react";


class CreateCharacterPointBuyStatsComponent extends React.Component {
	constructor(props) {
		super();
	}
	//PlaceHolder for the points buy component: start all stats at 10 and have either 10,15,20, 25 points to spend
	render() {
		return(
			<div style={{textAlign:'center'}}>Under construction</div>
		)}
}

export default CreateCharacterPointBuyStatsComponent;