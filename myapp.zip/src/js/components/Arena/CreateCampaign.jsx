import React from 'react';

export default class CreateCampaign extends React.Component {


	render() {
		return (
			<div>Under construction</div>
		);
	};

}