import React from 'react';

export default class CreateEncounter extends React.Component {


	render() {
		return (
			<div>Under construction</div>
		);
	};

}